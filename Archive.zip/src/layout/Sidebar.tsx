import { NavLink } from "react-router-dom";

export function Sidebar() {
    function logout() {
        localStorage.removeItem("token");
        window.location.href = "/login";
    }

  return (
    <aside className="sidebar">
      <div className="brand">
        <span style={{ width: 28, height: 28, borderRadius: 10, background: "rgba(79,70,229,0.18)", display: "inline-block" }} />

        <div>
          Expense Tracker
          <div className="muted" style={{ fontSize: 12 }}>Personal finance</div>
        </div>
      </div>



      <nav className="nav">
        <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>
          📊 Dashboard
        </NavLink>
        <NavLink to="/expenses" className={({ isActive }) => (isActive ? "active" : "")}>
          💸 Expenses
        </NavLink>
        <NavLink to="/budgets" className={({ isActive }) => (isActive ? "active" : "")}>
          🎯 Budgets
        </NavLink>
        <NavLink to="/investments" className={({ isActive }) => (isActive ? "active" : "")}>
          📈 Investments
        </NavLink>
        <NavLink to="/categories" className={({ isActive }) => (isActive ? "active" : "")}>
          🧩 Categories
        </NavLink>
      </nav>
      <div style={{ marginTop: 18, paddingTop: 12, borderTop: "1px solid var(--border)" }}>
        <button className="btn danger" style={{ width: "100%" }} onClick={logout}>
            Logout
        </button>
        </div>
      
    </aside>
  );
}
