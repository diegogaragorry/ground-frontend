import { useState } from "react";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";

export function AppShell(props: { title: string; subtitle?: string; children: React.ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  return (
    <div className="container">
      <Sidebar />

      {drawerOpen && (
        <div className="drawerOverlay" onClick={() => setDrawerOpen(false)}>
          <div className="drawer" onClick={(e) => e.stopPropagation()}>
            <Sidebar />
          </div>
        </div>
      )}

      <main className="main">
        <div style={{ display: "grid", gap: 14 }}>
          <Topbar
            title={props.title}
            subtitle={props.subtitle}
            onOpenMenu={() => setDrawerOpen(true)}
          />

          <style>{`
            @media (max-width: 900px) {
              #mobileMenuBtn { display: inline-flex !important; }
            }
          `}</style>

          {props.children}
        </div>
      </main>
    </div>
  );
}
