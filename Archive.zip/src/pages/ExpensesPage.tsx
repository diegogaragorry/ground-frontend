import { useEffect, useMemo, useState } from "react";
import { AppShell } from "../layout/AppShell";
import { api } from "../api";

type Category = { id: string; name: string };

type Expense = {
  id: string;
  description: string;
  amount: number;
  amountUsd: number;
  usdUyuRate?: number | null;
  date: string; // ISO
  currencyId: "UYU" | "USD" | string;
  categoryId: string;
  category: { id: string; name: string };
};

type SummaryRow = {
  categoryId: string;
  categoryName: string;
  currencyId: string;
  total: number;
};

type ExpensesSummary = {
  year: number;
  month: number;
  totalsByCategoryAndCurrency: SummaryRow[];
};

function ymNow() {
  const d = new Date();
  return { year: d.getFullYear(), month: d.getMonth() + 1 };
}

const usd0 = new Intl.NumberFormat(undefined, {
  maximumFractionDigits: 0,
  minimumFractionDigits: 0,
});

const num2 = new Intl.NumberFormat(undefined, {
  maximumFractionDigits: 2,
  minimumFractionDigits: 2,
});

function getFxDefault(): number {
  const raw = localStorage.getItem("usdUyuRateDefault");
  const v = raw ? Number(raw) : NaN;
  if (Number.isFinite(v) && v > 0) return v;
  // default que definiste
  localStorage.setItem("usdUyuRateDefault", "37.983");
  return 37.983;
}

function setFxDefault(v: number) {
  if (Number.isFinite(v) && v > 0) {
    localStorage.setItem("usdUyuRateDefault", String(v));
  }
}

export function ExpensesPage() {
  const now = useMemo(() => ymNow(), []);
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const [categories, setCategories] = useState<Category[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [summary, setSummary] = useState<ExpensesSummary | null>(null);

  // Create form
  const [description, setDescription] = useState("Supermercado");
  const [amount, setAmount] = useState<number>(100);
  const [currencyId, setCurrencyId] = useState<"UYU" | "USD">("UYU");
  const [usdUyuRate, setUsdUyuRate] = useState<number>(getFxDefault());
  const [categoryId, setCategoryId] = useState<string>("");
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0, 10));

  // Edit inline
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editDescription, setEditDescription] = useState("");
  const [editAmount, setEditAmount] = useState<number>(0);
  const [editCurrencyId, setEditCurrencyId] = useState<"UYU" | "USD">("UYU");
  const [editUsdUyuRate, setEditUsdUyuRate] = useState<number>(getFxDefault());
  const [editCategoryId, setEditCategoryId] = useState<string>("");
  const [editDate, setEditDate] = useState<string>("");

  async function loadCategories() {
    const cats = await api<Category[]>("/categories");
    setCategories(cats);
    if (!categoryId && cats.length > 0) setCategoryId(cats[0].id);
  }

  async function loadExpenses() {
    const list = await api<Expense[]>(`/expenses?year=${year}&month=${month}`);
    setExpenses(list);
  }

  async function loadSummary() {
    const data = await api<ExpensesSummary>(`/expenses/summary?year=${year}&month=${month}`);
    setSummary(data);
  }

  async function loadAll() {
    setError("");
    setLoading(true);
    try {
      await loadCategories();
      await Promise.all([loadExpenses(), loadSummary()]);
    } catch (err: any) {
      setError(err.message ?? "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, month]);

  async function createExpense(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    // persist default FX if user is working with UYU
    if (currencyId === "UYU") setFxDefault(usdUyuRate);

    try {
      await api("/expenses", {
        method: "POST",
        body: JSON.stringify({
          description,
          amount: Number(amount),
          currencyId,
          usdUyuRate: currencyId === "UYU" ? Number(usdUyuRate) : undefined,
          categoryId,
          date,
        }),
      });

      await Promise.all([loadExpenses(), loadSummary()]);
    } catch (err: any) {
      setError(err.message ?? "Error");
    }
  }

  function startEdit(exp: Expense) {
    setEditingId(exp.id);
    setEditDescription(exp.description);
    setEditAmount(exp.amount);
    setEditCurrencyId(exp.currencyId as any);
    setEditCategoryId(exp.categoryId);
    setEditDate(exp.date.slice(0, 10));

    // si es UYU, usar el rate guardado en el expense o fallback al default
    const rate =
      exp.currencyId === "UYU"
        ? Number(exp.usdUyuRate ?? getFxDefault())
        : getFxDefault();

    setEditUsdUyuRate(rate);
  }

  function cancelEdit() {
    setEditingId(null);
  }

  async function saveEdit(expenseId: string) {
    setError("");

    if (editCurrencyId === "UYU") setFxDefault(editUsdUyuRate);

    try {
      await api(`/expenses/${expenseId}`, {
        method: "PUT",
        body: JSON.stringify({
          description: editDescription,
          amount: Number(editAmount),
          currencyId: editCurrencyId,
          usdUyuRate: editCurrencyId === "UYU" ? Number(editUsdUyuRate) : undefined,
          categoryId: editCategoryId,
          date: editDate,
        }),
      });

      setEditingId(null);
      await Promise.all([loadExpenses(), loadSummary()]);
    } catch (err: any) {
      setError(err.message ?? "Error");
    }
  }

  async function removeExpense(expenseId: string) {
    setError("");
    try {
      await api(`/expenses/${expenseId}`, { method: "DELETE" });
      await Promise.all([loadExpenses(), loadSummary()]);
    } catch (err: any) {
      setError(err.message ?? "Error");
    }
  }

  const monthLabel = `${year}-${String(month).padStart(2, "0")}`;

  // USD: sin decimales
  const totalUsdMonth = useMemo(() => {
    const sum = expenses.reduce((acc, e) => acc + (e.amountUsd ?? 0), 0);
    return sum;
  }, [expenses]);

  return (
    <AppShell title="Expenses" subtitle="Track and edit your monthly spending (Base: USD)">
      <div className="grid">
        {/* Controls */}
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", flexWrap: "wrap" }}>
            <div className="row" style={{ flexWrap: "wrap" }}>
              <div style={{ minWidth: 140 }}>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Year</div>
                <input
                  className="input"
                  type="number"
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                />
              </div>

              <div style={{ minWidth: 140 }}>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Month</div>
                <input
                  className="input"
                  type="number"
                  min={1}
                  max={12}
                  value={month}
                  onChange={(e) => setMonth(Number(e.target.value))}
                />
              </div>

              <button className="btn" type="button" onClick={loadAll}>
                Refresh
              </button>
            </div>

            <div className="muted" style={{ fontSize: 12 }}>
              {loading ? "Loading…" : `Viewing: ${monthLabel} • Total USD: ${usd0.format(totalUsdMonth)}`}
            </div>
          </div>

          {error && <div style={{ marginTop: 12, color: "var(--danger)" }}>{error}</div>}
        </div>

        {/* Summary (USD, sin decimales) */}
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between" }}>
            <div>
              <div style={{ fontWeight: 750 }}>Monthly summary (USD)</div>
              <div className="muted" style={{ fontSize: 12 }}>Totals by category (converted to USD)</div>
            </div>
          </div>

          <div style={{ marginTop: 12 }}>
            {summary && summary.totalsByCategoryAndCurrency.length === 0 ? (
              <div className="muted">No expenses yet for this month.</div>
            ) : (
              <table className="table">
                <thead>
                  <tr>
                    <th>Category</th>
                    <th style={{ width: 90 }}>Curr</th>
                    <th className="right" style={{ width: 140 }}>Total (USD)</th>
                  </tr>
                </thead>
                <tbody>
                  {summary?.totalsByCategoryAndCurrency.map((r) => (
                    <tr key={`${r.categoryId}-${r.currencyId}`}>
                      <td>{r.categoryName}</td>
                      <td>USD</td>
                      <td className="right">{usd0.format(r.total)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Create */}
        <div className="card">
          <div style={{ fontWeight: 750, marginBottom: 10 }}>Add expense</div>

          <form
            onSubmit={createExpense}
            className="grid"
            style={{
              gridTemplateColumns:
                currencyId === "UYU"
                  ? "2fr 1fr 1fr 1fr 1.5fr 1.2fr auto"
                  : "2fr 1fr 1fr 1.5fr 1.2fr auto",
              alignItems: "end",
            }}
          >
            <div>
              <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Description</div>
              <input className="input" value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>

            <div>
              <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Amount</div>
              <input className="input" type="number" value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
            </div>

            <div>
              <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Currency</div>
              <select
                className="select"
                value={currencyId}
                onChange={(e) => {
                  const v = e.target.value as "UYU" | "USD";
                  setCurrencyId(v);
                  if (v === "UYU") setUsdUyuRate(getFxDefault());
                }}
              >
                <option value="UYU">UYU</option>
                <option value="USD">USD</option>
              </select>
            </div>

            {currencyId === "UYU" && (
              <div>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>FX (1 USD = X UYU)</div>
                <input
                  className="input"
                  type="number"
                  step="0.001"
                  value={usdUyuRate}
                  onChange={(e) => setUsdUyuRate(Number(e.target.value))}
                />
                <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
                  ≈ USD {usd0.format(amount / (usdUyuRate || 1))}
                </div>
              </div>
            )}

            <div>
              <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Category</div>
              <select className="select" value={categoryId} onChange={(e) => setCategoryId(e.target.value)}>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Date</div>
              <input className="input" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>

            <button className="btn primary" type="submit">Add</button>
          </form>
        </div>

        {/* Table */}
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 10, flexWrap: "wrap" }}>
            <div>
              <div style={{ fontWeight: 750 }}>Expenses</div>
              <div className="muted" style={{ fontSize: 12 }}>
                Shows original amount + USD equivalent (USD has no decimals)
              </div>
            </div>
            <div className="muted" style={{ fontSize: 12 }}>{expenses.length} items</div>
          </div>

          <table className="table">
            <thead>
              <tr>
                <th style={{ width: 120 }}>Date</th>
                <th>Description</th>
                <th style={{ width: 190 }}>Category</th>
                <th style={{ width: 130 }}>Original</th>
                <th className="right" style={{ width: 140 }}>USD</th>
                <th style={{ width: 230 }}>Actions</th>
              </tr>
            </thead>

            <tbody>
              {expenses.map((e) => {
                const isEditing = editingId === e.id;

                return (
                  <tr key={e.id}>
                    <td>
                      {isEditing ? (
                        <input className="input" type="date" value={editDate} onChange={(ev) => setEditDate(ev.target.value)} />
                      ) : (
                        e.date.slice(0, 10)
                      )}
                    </td>

                    <td>
                      {isEditing ? (
                        <input className="input" value={editDescription} onChange={(ev) => setEditDescription(ev.target.value)} />
                      ) : (
                        e.description
                      )}
                    </td>

                    <td>
                      {isEditing ? (
                        <select className="select" value={editCategoryId} onChange={(ev) => setEditCategoryId(ev.target.value)}>
                          {categories.map((c) => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      ) : (
                        e.category?.name
                      )}
                    </td>

                    {/* Original (amount + currency) */}
                    <td>
                      {isEditing ? (
                        <div className="row" style={{ gap: 8 }}>
                          <input
                            className="input"
                            type="number"
                            value={editAmount}
                            onChange={(ev) => setEditAmount(Number(ev.target.value))}
                            style={{ width: 110 }}
                          />
                          <select
                            className="select"
                            value={editCurrencyId}
                            onChange={(ev) => {
                              const v = ev.target.value as "UYU" | "USD";
                              setEditCurrencyId(v);
                              if (v === "UYU") setEditUsdUyuRate(getFxDefault());
                            }}
                            style={{ width: 90 }}
                          >
                            <option value="UYU">UYU</option>
                            <option value="USD">USD</option>
                          </select>

                          {editCurrencyId === "UYU" && (
                            <input
                              className="input"
                              type="number"
                              step="0.001"
                              value={editUsdUyuRate}
                              onChange={(ev) => setEditUsdUyuRate(Number(ev.target.value))}
                              style={{ width: 140 }}
                              title="FX: 1 USD = X UYU"
                            />
                          )}
                        </div>
                      ) : (
                        `${num2.format(e.amount)} ${e.currencyId}`
                      )}
                    </td>

                    {/* USD column */}
                    <td className="right">
                      {isEditing ? (
                        <span className="muted" title="USD is calculated from backend">
                          {editCurrencyId === "USD"
                            ? usd0.format(editAmount)
                            : usd0.format(editAmount / (editUsdUyuRate || 1))}
                        </span>
                      ) : (
                        usd0.format(e.currencyId === "USD" ? e.amount : e.amountUsd)
                      )}
                    </td>

                    <td>
                      {isEditing ? (
                        <div className="row" style={{ justifyContent: "flex-end" }}>
                          <button className="btn primary" type="button" onClick={() => saveEdit(e.id)}>Save</button>
                          <button className="btn" type="button" onClick={cancelEdit}>Cancel</button>
                        </div>
                      ) : (
                        <div className="row" style={{ justifyContent: "flex-end" }}>
                          <button className="btn" type="button" onClick={() => startEdit(e)}>Edit</button>
                          <button className="btn danger" type="button" onClick={() => removeExpense(e.id)}>Delete</button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}

              {expenses.length === 0 && (
                <tr>
                  <td colSpan={6} className="muted">
                    No expenses for this month yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>

          <div className="muted" style={{ marginTop: 10, fontSize: 12 }}>
            USD values are displayed without decimals (rounded).
          </div>
        </div>
      </div>
    </AppShell>
  );
}
