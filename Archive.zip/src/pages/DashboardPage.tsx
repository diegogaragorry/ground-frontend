import { useEffect, useMemo, useState } from "react";
import { AppShell } from "../layout/AppShell";
import { api } from "../api";

type Expense = {
  id: string;
  description: string;
  amount: number;
  amountUsd: number;
  currencyId: "UYU" | "USD" | string;
  date: string;
  category: { id: string; name: string };
};

type SummaryRow = {
  categoryId: string;
  categoryName: string;
  currencyId: string; // en tu backend ahora viene "USD"
  total: number; // USD
};

type ExpensesSummary = {
  year: number;
  month: number;
  totalsByCategoryAndCurrency: SummaryRow[];
};

type Investment = {
  id: string;
  name: string;
  type: string;
  createdAt: string;
};

type InvestmentPerformance = {
  investment: Investment;
  totalsByCurrency: Record<
    string,
    {
      deposits: number;
      withdrawals: number;
      yield: number;
      balance: number;
      netContrib: number;
      roi: number;
    }
  >;
  movementsCount: number;
};

function ymNow() {
  const d = new Date();
  return { year: d.getFullYear(), month: d.getMonth() + 1 };
}

const usd0 = new Intl.NumberFormat(undefined, {
  maximumFractionDigits: 0,
  minimumFractionDigits: 0,
});

export function DashboardPage() {
  const now = useMemo(() => ymNow(), []);
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [summary, setSummary] = useState<ExpensesSummary | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);

  const [investments, setInvestments] = useState<Investment[]>([]);
  const [invPerf, setInvPerf] = useState<Record<string, InvestmentPerformance>>({});

  async function load() {
    setLoading(true);
    setError("");
    try {
      const [sum, list, invs] = await Promise.all([
        api<ExpensesSummary>(`/expenses/summary?year=${year}&month=${month}`),
        api<Expense[]>(`/expenses?year=${year}&month=${month}`),
        api<Investment[]>(`/investments`),
      ]);

      setSummary(sum);
      setExpenses(list);

      setInvestments(invs);

      // performance en paralelo (limitamos a 4 para que no quede pesado)
      const top = invs.slice(0, 4);
      const perfs = await Promise.all(
        top.map((inv) => api<InvestmentPerformance>(`/investments/${inv.id}/performance`))
      );
      const map: Record<string, InvestmentPerformance> = {};
      for (const p of perfs) map[p.investment.id] = p;
      setInvPerf(map);
    } catch (e: any) {
      setError(e?.message ?? "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, month]);

  const monthLabel = `${year}-${String(month).padStart(2, "0")}`;

  const totalMonthUsd = useMemo(() => {
    return expenses.reduce((acc, e) => acc + (e.amountUsd ?? 0), 0);
  }, [expenses]);

  const topCategories = useMemo(() => {
    const rows = summary?.totalsByCategoryAndCurrency ?? [];
    return [...rows].sort((a, b) => (b.total ?? 0) - (a.total ?? 0)).slice(0, 6);
  }, [summary]);

  const lastExpenses = useMemo(() => expenses.slice(0, 8), [expenses]);

  return (
    <AppShell title="Dashboard" subtitle="Quick snapshot (Base: USD)">
      <div className="grid">
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", flexWrap: "wrap" }}>
            <div className="row" style={{ flexWrap: "wrap" }}>
              <div style={{ minWidth: 140 }}>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Year</div>
                <input className="input" type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} />
              </div>
              <div style={{ minWidth: 140 }}>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Month</div>
                <input className="input" type="number" min={1} max={12} value={month} onChange={(e) => setMonth(Number(e.target.value))} />
              </div>
              <button className="btn" type="button" onClick={load}>Refresh</button>
            </div>

            <div className="muted" style={{ fontSize: 12 }}>
              {loading ? "Loading…" : `Viewing: ${monthLabel}`}
            </div>
          </div>

          {error && <div style={{ marginTop: 12, color: "var(--danger)" }}>{error}</div>}
        </div>

        {/* Cards */}
        <div className="grid" style={{ gridTemplateColumns: "repeat(3, minmax(0, 1fr))" }}>
          <div className="card">
            <div className="muted" style={{ fontSize: 12 }}>Monthly expenses (USD)</div>
            <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>{usd0.format(totalMonthUsd)}</div>
            <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>No decimals • rounded</div>
          </div>

          <div className="card">
            <div className="muted" style={{ fontSize: 12 }}>Expenses count</div>
            <div style={{ fontSize: 28, fontWeight: 800, marginTop: 6 }}>{expenses.length}</div>
            <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>This month</div>
          </div>

          <div className="card">
            <div className="muted" style={{ fontSize: 12 }}>Top category (USD)</div>
            <div style={{ fontSize: 18, fontWeight: 800, marginTop: 8 }}>
              {topCategories[0]?.categoryName ?? "—"}
            </div>
            <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
              {topCategories[0] ? `USD ${usd0.format(topCategories[0].total)}` : "No data"}
            </div>
          </div>
        </div>

        <div className="grid" style={{ gridTemplateColumns: "1.2fr 1.8fr" }}>
          {/* Top categories */}
          <div className="card">
            <div style={{ fontWeight: 750 }}>Top categories (USD)</div>
            <div className="muted" style={{ fontSize: 12, marginTop: 4 }}>Converted totals</div>

            <div style={{ marginTop: 12 }}>
              {topCategories.length === 0 ? (
                <div className="muted">No expenses yet.</div>
              ) : (
                <table className="table">
                  <thead>
                    <tr>
                      <th>Category</th>
                      <th className="right" style={{ width: 120 }}>USD</th>
                    </tr>
                  </thead>
                  <tbody>
                    {topCategories.map((r) => (
                      <tr key={r.categoryId}>
                        <td>{r.categoryName}</td>
                        <td className="right">{usd0.format(r.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* Recent expenses */}
          <div className="card">
            <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
              <div>
                <div style={{ fontWeight: 750 }}>Latest expenses</div>
                <div className="muted" style={{ fontSize: 12 }}>Original + USD</div>
              </div>
            </div>

            <table className="table">
              <thead>
                <tr>
                  <th style={{ width: 110 }}>Date</th>
                  <th>Description</th>
                  <th style={{ width: 160 }}>Category</th>
                  <th style={{ width: 140 }}>Original</th>
                  <th className="right" style={{ width: 120 }}>USD</th>
                </tr>
              </thead>
              <tbody>
                {lastExpenses.map((e) => (
                  <tr key={e.id}>
                    <td>{e.date.slice(0, 10)}</td>
                    <td>{e.description}</td>
                    <td>{e.category?.name}</td>
                    <td>{`${e.amount.toFixed(2)} ${e.currencyId}`}</td>
                    <td className="right">{usd0.format(e.currencyId === "USD" ? e.amount : e.amountUsd)}</td>
                  </tr>
                ))}
                {expenses.length === 0 && (
                  <tr>
                    <td colSpan={5} className="muted">No expenses this month.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Investments snapshot */}
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
            <div>
              <div style={{ fontWeight: 750 }}>Investments snapshot</div>
              <div className="muted" style={{ fontSize: 12 }}>Top 4 (performance by currency)</div>
            </div>
            <div className="muted" style={{ fontSize: 12 }}>{investments.length} total</div>
          </div>

          {investments.length === 0 ? (
            <div className="muted">No investments yet.</div>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th style={{ width: 100 }}>Type</th>
                  <th style={{ width: 120 }}>Currency</th>
                  <th className="right" style={{ width: 130 }}>Balance</th>
                  <th className="right" style={{ width: 120 }}>ROI</th>
                </tr>
              </thead>
              <tbody>
                {investments.slice(0, 4).map((inv) => {
                  const p = invPerf[inv.id];
                  const currencies = p ? Object.keys(p.totalsByCurrency) : [];
                  const firstCur = currencies[0];

                  return (
                    <tr key={inv.id}>
                      <td>{inv.name}</td>
                      <td>{inv.type}</td>
                      <td>{firstCur ?? "—"}</td>
                      <td className="right">
                        {firstCur ? p.totalsByCurrency[firstCur].balance.toFixed(2) : "—"}
                      </td>
                      <td className="right">
                        {firstCur ? `${Math.round(p.totalsByCurrency[firstCur].roi * 100)}%` : "—"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          <div className="muted" style={{ fontSize: 12, marginTop: 10 }}>
            Next step: convert investment performance to USD base (same as expenses).
          </div>
        </div>
      </div>
    </AppShell>
  );
}
