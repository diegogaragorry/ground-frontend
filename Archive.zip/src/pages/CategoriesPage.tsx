import { useEffect, useState } from "react";
import { AppShell } from "../layout/AppShell";
import { api } from "../api";

type Category = { id: string; name: string };

export function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [newName, setNewName] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");

  async function loadCategories() {
    const data = await api<Category[]>("/categories");
    setCategories(data);
  }

  useEffect(() => {
    loadCategories().catch((err: any) => setError(err.message ?? "Error"));
  }, []);

  async function createCategory(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setInfo("");

    const name = newName.trim();
    if (!name) return;

    try {
      await api("/categories", { method: "POST", body: JSON.stringify({ name }) });
      setNewName("");
      await loadCategories();
      setInfo("Category created.");
    } catch (err: any) {
      setError(err.message ?? "Error");
    }
  }

  function startEdit(c: Category) {
    setEditingId(c.id);
    setEditValue(c.name);
    setError("");
    setInfo("");
  }

  function cancelEdit() {
    setEditingId(null);
    setEditValue("");
  }

  async function saveEdit(e: React.FormEvent) {
    e.preventDefault();
    if (!editingId) return;

    setError("");
    setInfo("");

    const name = editValue.trim();
    if (!name) return;

    try {
      await api(`/categories/${editingId}`, { method: "PUT", body: JSON.stringify({ name }) });
      setEditingId(null);
      setEditValue("");
      await loadCategories();
      setInfo("Category updated.");
    } catch (err: any) {
      setError(err.message ?? "Error");
    }
  }

  async function removeCategory(id: string) {
    setError("");
    setInfo("");
    try {
      await api(`/categories/${id}`, { method: "DELETE" });
      await loadCategories();
      setInfo("Category deleted.");
    } catch (err: any) {
      // 409 esperable si tiene gastos
      const msg = err.message ?? "Error";
      setError(
        msg.includes("Cannot delete")
          ? "This category has expenses linked. Remove or reassign those expenses first."
          : msg
      );
    }
  }

  return (
    <AppShell title="Categories" subtitle="Manage categories used by expenses and budgets">
      <div className="grid">
        <div className="card">
          <div style={{ fontWeight: 750, marginBottom: 10 }}>Add category</div>

          <form onSubmit={createCategory} className="row" style={{ alignItems: "end", flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 260 }}>
              <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Name</div>
              <input className="input" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="e.g. Supermarket" />
            </div>

            <button className="btn primary" type="submit">Add</button>
          </form>

          {error && <div style={{ marginTop: 12, color: "var(--danger)" }}>{error}</div>}
          {info && <div style={{ marginTop: 12, color: "rgba(15,23,42,0.75)" }}>{info}</div>}

          <div style={{ marginTop: 12 }} className="muted">
            Tip: If a category has linked expenses, it can’t be deleted.
          </div>
        </div>

        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
            <div>
              <div style={{ fontWeight: 750 }}>Your categories</div>
              <div className="muted" style={{ fontSize: 12 }}>Rename or delete</div>
            </div>
            <div className="muted" style={{ fontSize: 12 }}>{categories.length} items</div>
          </div>

          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th style={{ width: 220 }}>Actions</th>
              </tr>
            </thead>

            <tbody>
              {categories.map((c) => {
                const isEditing = editingId === c.id;

                return (
                  <tr key={c.id}>
                    <td>
                      {isEditing ? (
                        <form onSubmit={saveEdit} className="row" style={{ gap: 8 }}>
                          <input className="input" value={editValue} onChange={(e) => setEditValue(e.target.value)} />
                        </form>
                      ) : (
                        c.name
                      )}
                    </td>

                    <td>
                      {isEditing ? (
                        <div className="row" style={{ justifyContent: "flex-end" }}>
                          <button className="btn primary" type="button" onClick={() => saveEdit(new Event("submit") as any)}>
                            Save
                          </button>
                          <button className="btn" type="button" onClick={cancelEdit}>
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="row" style={{ justifyContent: "flex-end" }}>
                          <button className="btn" type="button" onClick={() => startEdit(c)}>
                            Rename
                          </button>
                          <button className="btn danger" type="button" onClick={() => removeCategory(c.id)}>
                            Delete
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}

              {categories.length === 0 && (
                <tr>
                  <td colSpan={2} className="muted">
                    No categories yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
