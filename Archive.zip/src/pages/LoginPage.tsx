import { useState } from "react";
import { login, register } from "../auth"; // tu archivo actual src/auth.ts

export function LoginPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("secure2@test.com");
  const [password, setPassword] = useState("123456");
  const [error, setError] = useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      if (mode === "register") {
        await register(email, password);
        setMode("login");
        return;
      }
      const result = await login(email, password);
      localStorage.setItem("token", result.token);
      window.location.href = "/";
    } catch (err: any) {
      setError(err.message ?? "Error");
    }
  }

  return (
    <div style={{ maxWidth: 520, margin: "40px auto", padding: 18 }}>
      <div className="card">
        <div className="brand" style={{ marginBottom: 12 }}>
          <span style={{ width: 28, height: 28, borderRadius: 10, background: "rgba(79,70,229,0.18)", display: "inline-block" }} />

          <div>
            Expense Tracker
            <div className="muted" style={{ fontSize: 12 }}>Sign in to continue</div>
          </div>
        </div>

        <div className="row" style={{ marginBottom: 12 }}>
          <button className={"btn " + (mode === "login" ? "primary" : "")} onClick={() => setMode("login")}>Login</button>
          <button className={"btn " + (mode === "register" ? "primary" : "")} onClick={() => setMode("register")}>Register</button>
        </div>

        <form onSubmit={onSubmit} className="grid">
          <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
          <input className="input" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" type="password" />
          <button className="btn primary" type="submit">{mode === "login" ? "Login" : "Register"}</button>
          {error && <div style={{ color: "var(--danger)" }}>{error}</div>}
        </form>
      </div>
    </div>
  );
}
