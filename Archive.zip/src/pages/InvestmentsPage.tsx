import { useEffect, useMemo, useState } from "react";

type Investment = {
  id: string;
  name: string;
  type: string;
  currencyId: "USD" | "UYU" | string;
  targetAnnualReturn: number; // 0.08
  yieldStartYear: number;
  yieldStartMonth: number;
};

type CurrencyTotals = {
  closingCapital: number | null;
  closingCapitalUsd: number | null;
  isClosed: boolean;
};

function fmtUSD(n: number | null | undefined) {
  if (n === null || n === undefined) return "—";
  // sin decimales
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(n);
}

function ymValue(y: number, m: number) {
  return y * 12 + (m - 1);
}

export default function InvestmentsPage() {
  const token = localStorage.getItem("token") || "";
  const [investments, setInvestments] = useState<Investment[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [year] = useState(2026);
  const [month] = useState(1);

  // Map simple para “capital del mes” (por ahora no cargamos snapshots; lo hacemos en el siguiente paso)
  const [capitals, setCapitals] = useState<Record<string, CurrencyTotals>>({});

  const selected = useMemo(
    () => investments.find((i) => i.id === selectedId) || null,
    [investments, selectedId]
  );

  useEffect(() => {
    const load = async () => {
      const res = await fetch("http://localhost:3000/investments", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return;
      const data = await res.json();
      setInvestments(data);
      if (!selectedId && data.length) setSelectedId(data[0].id);
    };
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const projectedMonthlyUsd = (inv: Investment, capitalUsd: number | null) => {
    if (!capitalUsd) return 0;
    const starts = ymValue(inv.yieldStartYear, inv.yieldStartMonth);
    const current = ymValue(year, month);
    if (current < starts) return 0;
    return Math.round(capitalUsd * (inv.targetAnnualReturn / 12));
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold">Investments</h1>
        <p className="text-sm text-gray-600">
          Portfolio en USD + proyección mensual (sin decimales) con “rentabilidad desde”.
        </p>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Tabla */}
        <div className="col-span-12 lg:col-span-8 rounded-xl border bg-white">
          <div className="border-b px-4 py-3 text-sm font-medium text-gray-700">
            Portfolio
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-left text-gray-600">
                <tr>
                  <th className="px-4 py-3">Fondo</th>
                  <th className="px-4 py-3">Moneda</th>
                  <th className="px-4 py-3">Capital (USD)</th>
                  <th className="px-4 py-3">Target anual</th>
                  <th className="px-4 py-3">Rentabilidad desde</th>
                  <th className="px-4 py-3">Ingreso proyectado (mes)</th>
                </tr>
              </thead>
              <tbody>
                {investments.map((inv) => {
                  const cap = capitals[inv.id]?.closingCapitalUsd ?? null;
                  const proj = projectedMonthlyUsd(inv, cap);
                  const isSelected = inv.id === selectedId;

                  return (
                    <tr
                      key={inv.id}
                      className={`border-t hover:bg-gray-50 cursor-pointer ${
                        isSelected ? "bg-gray-50" : ""
                      }`}
                      onClick={() => setSelectedId(inv.id)}
                    >
                      <td className="px-4 py-3 font-medium text-gray-800">{inv.name}</td>
                      <td className="px-4 py-3 text-gray-700">{inv.currencyId}</td>
                      <td className="px-4 py-3 text-gray-800">{fmtUSD(cap)}</td>
                      <td className="px-4 py-3 text-gray-700">
                        {Math.round((inv.targetAnnualReturn ?? 0) * 100)}%
                      </td>
                      <td className="px-4 py-3 text-gray-700">
                        {String(inv.yieldStartMonth).padStart(2, "0")}/{inv.yieldStartYear}
                      </td>
                      <td className="px-4 py-3 text-gray-900">{fmtUSD(proj)}</td>
                    </tr>
                  );
                })}

                {!investments.length && (
                  <tr>
                    <td className="px-4 py-6 text-gray-600" colSpan={6}>
                      No hay inversiones todavía.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="px-4 py-3 text-xs text-gray-500">
            Nota: por ahora el “Capital (USD)” está vacío; en el próximo paso lo cargamos desde snapshots.
          </div>
        </div>

        {/* Panel */}
        <div className="col-span-12 lg:col-span-4 rounded-xl border bg-white">
          <div className="border-b px-4 py-3 text-sm font-medium text-gray-700">
            Configuración
          </div>

          <div className="p-4">
            {!selected ? (
              <div className="text-sm text-gray-600">Seleccioná una inversión.</div>
            ) : (
              <div className="space-y-4">
                <div>
                  <div className="text-sm font-medium text-gray-800">{selected.name}</div>
                  <div className="text-xs text-gray-500">{selected.type}</div>
                </div>

                <div className="rounded-lg bg-gray-50 p-3 text-sm text-gray-700">
                  En el siguiente paso vamos a:
                  <ul className="list-disc pl-5 mt-2 space-y-1">
                    <li>Traer snapshots del año y mostrar capital real.</li>
                    <li>Editar target anual y “rentabilidad desde”.</li>
                    <li>Setear capital del mes y cerrar mes.</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
