import { useEffect, useMemo, useState } from "react";
import { AppShell } from "../layout/AppShell";
import { api } from "../api";

type Category = { id: string; name: string };

type BudgetRow = {
  categoryId: string;
  categoryName: string;
  currencyId: "UYU" | "USD" | string;
  budget: number;
  actual: number;
  diff: number;
  pct: number; // actual/budget (0..)
};

type BudgetReport = {
  year: number;
  month: number;
  rows: BudgetRow[];
};

function ymNow() {
  const d = new Date();
  return { year: d.getFullYear(), month: d.getMonth() + 1 };
}

function pctLabel(p: number) {
  if (!Number.isFinite(p)) return "-";
  return `${Math.round(p * 100)}%`;
}

export function BudgetsPage() {
  const now = useMemo(() => ymNow(), []);
  const [year, setYear] = useState(now.year);
  const [month, setMonth] = useState(now.month);

  const [categories, setCategories] = useState<Category[]>([]);
  const [report, setReport] = useState<BudgetReport | null>(null);

  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);

  // Editor
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>("");
  const [selectedCurrencyId, setSelectedCurrencyId] = useState<"UYU" | "USD">("UYU");
  const [selectedAmount, setSelectedAmount] = useState<number>(0);

  async function loadCategories() {
    const cats = await api<Category[]>("/categories");
    setCategories(cats);
    if (!selectedCategoryId && cats.length > 0) setSelectedCategoryId(cats[0].id);
  }

  async function loadReport() {
    const data = await api<BudgetReport>(`/budgets/report?year=${year}&month=${month}`);
    setReport(data);

    // si hay filas, precargamos el editor con la primera fila (nice UX)
    if (data.rows.length > 0 && !selectedCategoryId) {
      setSelectedCategoryId(data.rows[0].categoryId);
      setSelectedCurrencyId(data.rows[0].currencyId as any);
      setSelectedAmount(data.rows[0].budget);
    }
  }

  async function loadAll() {
    setError("");
    setInfo("");
    setLoading(true);
    try {
      await loadCategories();
      await loadReport();
    } catch (err: any) {
      setError(err.message ?? "Error");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, month]);

  function onSelectRow(r: BudgetRow) {
    setSelectedCategoryId(r.categoryId);
    setSelectedCurrencyId(r.currencyId as any);
    setSelectedAmount(r.budget);
    setInfo("");
    setError("");
  }

  async function saveBudget(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setInfo("");

    if (!selectedCategoryId) {
      setError("Select a category");
      return;
    }

    try {
      await api("/budgets", {
        method: "POST",
        body: JSON.stringify({
          year,
          month,
          categoryId: selectedCategoryId,
          currencyId: selectedCurrencyId,
          amount: Number(selectedAmount),
        }),
      });

      setInfo("Budget saved.");
      await loadReport();
    } catch (err: any) {
      setError(err.message ?? "Error");
    }
  }

  const selectedCategoryName =
    categories.find((c) => c.id === selectedCategoryId)?.name ?? "—";

  return (
    <AppShell title="Budgets" subtitle="Plan vs actual spending">
      <div className="grid">
        {/* Controls */}
        <div className="card">
          <div className="row" style={{ justifyContent: "space-between", flexWrap: "wrap" }}>
            <div className="row" style={{ flexWrap: "wrap" }}>
              <div style={{ minWidth: 140 }}>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Year</div>
                <input className="input" type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} />
              </div>

              <div style={{ minWidth: 140 }}>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Month</div>
                <input className="input" type="number" min={1} max={12} value={month} onChange={(e) => setMonth(Number(e.target.value))} />
              </div>

              <button className="btn" type="button" onClick={loadAll}>
                Refresh
              </button>
            </div>

            <div className="muted" style={{ fontSize: 12 }}>
              {loading ? "Loading…" : `Rows: ${report?.rows.length ?? 0}`}
            </div>
          </div>

          {error && <div style={{ marginTop: 12, color: "var(--danger)" }}>{error}</div>}
          {info && <div style={{ marginTop: 12, color: "rgba(15,23,42,0.75)" }}>{info}</div>}
        </div>

        <div className="grid" style={{ gridTemplateColumns: "2fr 1fr", alignItems: "start" }}>
          {/* Report table */}
          <div className="card">
            <div className="row" style={{ justifyContent: "space-between", marginBottom: 10 }}>
              <div>
                <div style={{ fontWeight: 750 }}>Budget vs Actual</div>
                <div className="muted" style={{ fontSize: 12 }}>Click a row to edit its budget</div>
              </div>
            </div>

            <table className="table">
              <thead>
                <tr>
                  <th>Category</th>
                  <th style={{ width: 90 }}>Curr</th>
                  <th className="right" style={{ width: 120 }}>Budget</th>
                  <th className="right" style={{ width: 120 }}>Actual</th>
                  <th className="right" style={{ width: 120 }}>Diff</th>
                  <th className="right" style={{ width: 80 }}>%</th>
                </tr>
              </thead>
              <tbody>
                {(report?.rows ?? []).map((r) => {
                  const active =
                    r.categoryId === selectedCategoryId &&
                    r.currencyId === selectedCurrencyId;

                  return (
                    <tr
                      key={`${r.categoryId}-${r.currencyId}`}
                      onClick={() => onSelectRow(r)}
                      style={{
                        cursor: "pointer",
                        background: active ? "rgba(79,70,229,0.08)" : "transparent",
                      }}
                      title="Click to edit"
                    >
                      <td>{r.categoryName}</td>
                      <td>{r.currencyId}</td>
                      <td className="right">{r.budget.toFixed(2)}</td>
                      <td className="right">{r.actual.toFixed(2)}</td>
                      <td className="right">{r.diff.toFixed(2)}</td>
                      <td className="right">{pctLabel(r.pct)}</td>
                    </tr>
                  );
                })}

                {(report?.rows ?? []).length === 0 && (
                  <tr>
                    <td colSpan={6} className="muted">
                      No data yet. Add expenses and/or budgets for this month.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Editor */}
          <div className="card">
            <div style={{ fontWeight: 750, marginBottom: 6 }}>Edit budget</div>
            <div className="muted" style={{ fontSize: 12, marginBottom: 12 }}>
              {selectedCategoryId ? `Editing: ${selectedCategoryName}` : "Select a row or choose a category"}
            </div>

            <form onSubmit={saveBudget} className="grid">
              <div>
                <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Category</div>
                <select className="select" value={selectedCategoryId} onChange={(e) => setSelectedCategoryId(e.target.value)}>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="row">
                <div style={{ flex: 1 }}>
                  <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Currency</div>
                  <select className="select" value={selectedCurrencyId} onChange={(e) => setSelectedCurrencyId(e.target.value as any)}>
                    <option value="UYU">UYU</option>
                    <option value="USD">USD</option>
                  </select>
                </div>

                <div style={{ flex: 1 }}>
                  <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Amount</div>
                  <input className="input" type="number" value={selectedAmount} onChange={(e) => setSelectedAmount(Number(e.target.value))} />
                </div>
              </div>

              <button className="btn primary" type="submit">Save budget</button>

              <div className="muted" style={{ fontSize: 12 }}>
                Tip: budgets are per month + category + currency.
              </div>
            </form>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
